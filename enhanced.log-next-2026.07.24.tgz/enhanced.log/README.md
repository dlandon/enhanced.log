**Enhanced Log Viewer - Next**

This plugin is an Enhanced Syslog page to view the system log with highlighted lines.  You can enable or disable event highlighting and set your own colors for each event.  You can add your own search string to highlight in the log.  There is also a log filter to filter log entries.

Originally developed and maintained by Dan Landon.

Project repository, documentation, and license information are available on GitHub.