<?php
/* Copyright 2015-2026 Dan Landon
 *
 * Permission is granted to use this software for personal, educational, or internal use only.
 * Commercial use, redistribution, or modification of this software or any derived works
 * is strictly prohibited without prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 */

/* Define our plugin name. */
define('ENHANCED_LOG_PLUGIN', 'enhanced.log');

/* Define the docroot path. */
if (!defined('DOCROOT')) {
	define('DOCROOT', $_SERVER['DOCUMENT_ROOT'] ?: '/usr/local/emhttp');
}

/* Default filter text. */
$filter_text = trim($_COOKIE['enhanced_log_filter'] ?? '');

/*
 * Filter an array of text lines.
 *
 * Filter syntax:
 *   term          Include lines containing "term"
 *   term1,term2   Include lines matching all terms (logical AND)
 *   !term         Exclude lines containing "term"
 *   *.txt         Wildcards '*' and '?' supported
 *
 * Matching is case-insensitive and UTF-8 aware when mbstring is available.
 */
function filter_text_lines(array $lines, string $filter_text): array {
	$filter_text = trim($filter_text);

	if ($filter_text === '') {
		return $lines;
	}

	$terms  = array_filter(array_map('trim', explode(',', $filter_text)));
	$use_mb = function_exists('mb_stripos');

	return array_values(array_filter($lines, static function ($line) use ($terms, $use_mb) {
		foreach ($terms as $term) {
			$exclude = false;

			/* Leading '!' excludes matching lines. */
			if (isset($term[0]) && $term[0] === '!') {
				$exclude = true;
				$term = trim(substr($term, 1));

				/* Ignore a bare '!'. */
				if ($term === '') {
					continue;
				}
			}

			/* Wildcard match? */
			if (strpbrk($term, '*?') !== false) {
				$regex = '/.*' .
					str_replace(
						['\*', '\?'],
						['.*', '.'],
						preg_quote($term, '/')
					) .
					'.*/iu';

				$matched = (bool)preg_match($regex, $line);
			} else {
				$matched = $use_mb
					? (mb_stripos($line, $term) !== false)
					: (stripos($line, $term) !== false);
			}

			if ($exclude) {
				if ($matched) {
					return false;
				}
			} else {
				if (!$matched) {
					return false;
				}
			}
		}

		return true;
	}));
}

$filter_help = implode("\n", [
	_("Enter one or more comma-separated search terms").".",
	_("All terms must match unless prefixed with '!'"),
	_("Use '!' to exclude matching entries."),
	_("Wildcards")." '*' "._("and")." '?' "._("are supported").".",
	_("Example").": 'disk4', 'I/O error', '!emhttp'"
]);
?>
